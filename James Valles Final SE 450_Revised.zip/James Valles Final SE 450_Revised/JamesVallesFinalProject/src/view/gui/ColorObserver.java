package view.gui;

import controller.ShapeCreateCommand;
import model.ShapeConfiguration;
import model.ShapeFactory;
import model.ShapeList;
import model.dialogs.ColorSingleton;
import model.interfaces.IApplicationState;
import model.interfaces.IShapeListSubject;
import view.interfaces.IDrawShape;

public class ColorObserver implements IColorObserver {
    ShapeConfiguration shapeConfiguration;
    IShapeListSubject shapeList;
    IApplicationState applicationState;


    public ColorObserver(ShapeConfiguration shapeConfiguration, IShapeListSubject shapeList, IApplicationState applicationState) {
        this.shapeList = shapeList;
        this.shapeConfiguration = shapeConfiguration;
        this.applicationState = applicationState;
        applicationState.registerColorObserver(this);
    }


    @Override
    public void run() {
        //System.out.println(shapeList.getSelectedShapesList().size());
        for (IDrawShape shape : shapeList.getSelectedShapesList()) {
            shape.setPrimaryColor(ColorSingleton.getColor(applicationState.getActivePrimaryColor()));
            shape.setSecondaryColor(ColorSingleton.getColor(applicationState.getActiveSecondaryColor()));
            shape.setShapeShadingType(applicationState.getActiveShapeShadingType());
            // ShapeCreateCommand newshape = new ShapeCreateCommand(applicationState, shapeList, shape.getShapeConfiguration());
            //newshape.run();
        }
        shapeList.notifyObserver();
        shapeList.getSelectedShapesList().clear();
       // System.out.println("This is working");
    }
}
