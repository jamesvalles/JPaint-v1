package view.gui;

public interface IColorObserver {
    void run();
}
