package view.interfaces;

public interface IMouseAdapterObserver {
    void run();
}
