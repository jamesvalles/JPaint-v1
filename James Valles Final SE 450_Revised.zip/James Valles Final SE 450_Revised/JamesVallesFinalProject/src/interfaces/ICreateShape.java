package interfaces;

public interface ICreateShape {
}
