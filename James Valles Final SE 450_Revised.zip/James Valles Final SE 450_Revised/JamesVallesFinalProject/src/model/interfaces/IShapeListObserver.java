package model.interfaces;

import view.gui.PaintCanvas;
import view.interfaces.IDrawShape;
import view.interfaces.IShadedShape;

import java.util.List;

public interface IShapeListObserver {
    void update();
}
